getairq <- function()

{


}
