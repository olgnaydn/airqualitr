clusteredmaps<- function(city)
  
{
  #clusteredmaps(city): This function builds map with bubbes for defined city.
  #Bubble sizes are defined with related attribute value
  
}

