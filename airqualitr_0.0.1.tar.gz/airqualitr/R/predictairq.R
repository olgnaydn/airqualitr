predictairq <- function(lat,lon, attribute)
{
  #predictairq(lat,lon, attribute): Function is for predicting air quality values for user defined attribute and geolocation
  #Restrictions should be defined for this function
  
}